#!/bin/bash
cd runtime
SERIAL=ANYJTAG ./flashandmonitor.sh
